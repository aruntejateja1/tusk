package com.springboot.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

//import javax.management.Query;

//import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.provider.HibernateUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.springboot.entity.Product;
import com.springboot.entity.User;

import com.springboot.repository.UserRepository;


@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	
	private JdbcTemplate jdbc;
	
	
	public User saveUser(User user) {
		return userRepository.save(user);
	}
	
	public List<User> getUsers(){
		return userRepository.findAll();
	}
	
	
}
