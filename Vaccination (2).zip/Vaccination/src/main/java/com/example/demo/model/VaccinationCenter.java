package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="vaccinationcenter")

public class VaccinationCenter {

	@Column(name="pincode")
	private String pincode;
	
	@Id
	@Column(name="vName")
	private String vName;
	@Column(name="vType")
	private String vType;
	@Column(name="vStime")
	private String vStime;
	@Column(name="vEtime")
	private String vEtime;
	@Column(name="vContact")
	private String vContact;
	@Column(name="vAddress")
	private String vAddress;
	@Column(name="vaccinename")
	private String vaccineName;
	
	@Column(name="age")
	private String age;
	@Column(name="vAvailable")
	private int vAvailable;
	@Column(name="cost")
	private int cost;
	
	private String vCode;
	private String vPassword;
	
	public String getvCode() {
		return vCode;
	}
	public void setvCode(String vCode) {
		this.vCode = vCode;
	}
	public String getvPassword() {
		return vPassword;
	}
	public void setvPassword(String vPassword) {
		this.vPassword = vPassword;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getvName() {
		return vName;
	}
	public void setvName(String vName) {
		this.vName = vName;
	}
	public String getvType() {
		return vType;
	}
	public void setvType(String vType) {
		this.vType = vType;
	}
	public String getvStime() {
		return vStime;
	}
	public void setvStime(String vStime) {
		this.vStime = vStime;
	}
	public String getvEtime() {
		return vEtime;
	}
	public void setvEtime(String vEtime) {
		this.vEtime = vEtime;
	}
	public String getvContact() {
		return vContact;
	}
	public void setvContact(String vContact) {
		this.vContact = vContact;
	}
	public String getvAddress() {
		return vAddress;
	}
	public void setvAddress(String vAddress) {
		this.vAddress = vAddress;
	}
	public String getVaccineName() {
		return vaccineName;
	}
	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public int getvAvailable() {
		return vAvailable;
	}
	public void setvAvailable(int vAvailable) {
		this.vAvailable = vAvailable;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "VaccinationCenter [pincode=" + pincode + ", vName=" + vName + ", vType=" + vType + ", vStime=" + vStime
				+ ", vEtime=" + vEtime + ", vContact=" + vContact + ", vAddress=" + vAddress + ", vaccineName="
				+ vaccineName + ", age=" + age + ", vAvailable=" + vAvailable + ", cost=" + cost + "]";
	}
	
}
