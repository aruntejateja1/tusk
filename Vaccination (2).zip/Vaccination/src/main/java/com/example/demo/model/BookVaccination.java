package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BookVaccination {

	@Id
	private String aadharNumber;
	private String appointmentNumber;
	private String fullName;
	private String vName;
	private String vaccineName;
	private String dateslot;
	private String timeslot;
	private String vAddress;
	private String age;
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	
	public String getAppointmentNumber() {
		return appointmentNumber;
	}
	public void setAppointmentNumber(String appointmentNumber) {
		this.appointmentNumber = appointmentNumber;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getvName() {
		return vName;
	}
	public void setvName(String vName) {
		this.vName = vName;
	}
	public String getVaccineName() {
		return vaccineName;
	}
	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}
	public String getDateslot() {
		return dateslot;
	}
	public void setDateslot(String dateslot) {
		this.dateslot = dateslot;
	}
	public String getTimeslot() {
		return timeslot;
	}
	public void setTimeslot(String timeslot) {
		this.timeslot = timeslot;
	}
	public String getvAddress() {
		return vAddress;
	}
	public void setvAddress(String vAddress) {
		this.vAddress = vAddress;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String string) {
		this.age = string;
	}
	@Override
	public String toString() {
		return "BookVaccination [aadharNumber=" + aadharNumber + ", fullName=" + fullName + ", vName=" + vName
				+ ", vaccineName=" + vaccineName + ", dateslot=" + dateslot + ", timeslot=" + timeslot + ", vAddress="
				+ vAddress + ", age=" + age + "]";
	}
	
}
