create table shoppingdb.cart (idcart bigint not null auto_increment, id bigint not null, primary key (idcart)) engine=InnoDB
create table shoppingdb.customers (id bigint not null auto_increment, password varchar(255), username varchar(255), primary key (id)) engine=InnoDB
create table shoppingdb.orders (idorder bigint not null auto_increment, ordered datetime(6), total decimal(19,2), id bigint not null, primary key (idorder)) engine=InnoDB
create table shoppingdb.product (idproduct bigint not null auto_increment, price decimal(19,2), productname varchar(255), stockavailable bigint, primary key (idproduct)) engine=InnoDB
alter table shoppingdb.cart add constraint FKj5b3osvko2sibhlrxwinq6s9a foreign key (id) references shoppingdb.customers (id)
alter table shoppingdb.orders add constraint FKqlf4gt3wiif5nxtwohsjabyi2 foreign key (id) references shoppingdb.customers (id)
create table shoppingdb.cart (idcart bigint not null auto_increment, id bigint not null, primary key (idcart)) engine=InnoDB
create table shoppingdb.customers (id bigint not null auto_increment, password varchar(255), username varchar(255), primary key (id)) engine=InnoDB
create table shoppingdb.orders (idorder bigint not null auto_increment, ordered datetime(6), total decimal(19,2), id bigint not null, primary key (idorder)) engine=InnoDB
create table shoppingdb.product (idproduct bigint not null auto_increment, price decimal(19,2), productname varchar(255), stockavailable bigint, primary key (idproduct)) engine=InnoDB
alter table shoppingdb.cart add constraint FKj5b3osvko2sibhlrxwinq6s9a foreign key (id) references shoppingdb.customers (id)
alter table shoppingdb.orders add constraint FKqlf4gt3wiif5nxtwohsjabyi2 foreign key (id) references shoppingdb.customers (id)
create table shoppingdb.cart (idcart bigint not null auto_increment, id bigint not null, primary key (idcart)) engine=InnoDB
create table shoppingdb.customers (id bigint not null auto_increment, password varchar(255), username varchar(255), primary key (id)) engine=InnoDB
create table shoppingdb.orders (idorder bigint not null auto_increment, ordered datetime(6), total decimal(19,2), id bigint not null, primary key (idorder)) engine=InnoDB
create table shoppingdb.product (idproduct bigint not null auto_increment, price decimal(19,2), productname varchar(255), stockavailable bigint, primary key (idproduct)) engine=InnoDB
alter table shoppingdb.cart add constraint FKj5b3osvko2sibhlrxwinq6s9a foreign key (id) references shoppingdb.customers (id)
alter table shoppingdb.orders add constraint FKqlf4gt3wiif5nxtwohsjabyi2 foreign key (id) references shoppingdb.customers (id)
create table shoppingdb.cart (idcart bigint not null auto_increment, id bigint not null, primary key (idcart)) engine=InnoDB
create table shoppingdb.customers (id bigint not null auto_increment, password varchar(255), username varchar(255), primary key (id)) engine=InnoDB
create table shoppingdb.orders (idorder bigint not null auto_increment, ordered datetime(6), total decimal(19,2), id bigint not null, primary key (idorder)) engine=InnoDB
create table shoppingdb.product (idproduct bigint not null auto_increment, price decimal(19,2), productname varchar(255), stockavailable bigint, primary key (idproduct)) engine=InnoDB
alter table shoppingdb.cart add constraint FKj5b3osvko2sibhlrxwinq6s9a foreign key (id) references shoppingdb.customers (id)
alter table shoppingdb.orders add constraint FKqlf4gt3wiif5nxtwohsjabyi2 foreign key (id) references shoppingdb.customers (id)
create table shoppingdb.cart (idcart bigint not null auto_increment, id bigint not null, primary key (idcart)) engine=InnoDB
create table shoppingdb.customers (id bigint not null auto_increment, password varchar(255), username varchar(255), primary key (id)) engine=InnoDB
create table shoppingdb.orders (idorder bigint not null auto_increment, ordered datetime(6), total decimal(19,2), id bigint not null, primary key (idorder)) engine=InnoDB
create table shoppingdb.product (idproduct bigint not null auto_increment, price decimal(19,2), productname varchar(255), stockavailable bigint, primary key (idproduct)) engine=InnoDB
alter table shoppingdb.cart add constraint FKj5b3osvko2sibhlrxwinq6s9a foreign key (id) references shoppingdb.customers (id)
alter table shoppingdb.orders add constraint FKqlf4gt3wiif5nxtwohsjabyi2 foreign key (id) references shoppingdb.customers (id)
create table shoppingdb.cart (idcar bigint not null auto_increment, id bigint not null, primary key (idcar)) engine=InnoDB
create table shoppingdb.customers (id bigint not null auto_increment, password varchar(255), username varchar(255), primary key (id)) engine=InnoDB
create table shoppingdb.orders (idorder bigint not null auto_increment, ordered datetime(6), total decimal(19,2), id bigint not null, primary key (idorder)) engine=InnoDB
create table shoppingdb.product (idproduct bigint not null auto_increment, price decimal(19,2), productname varchar(255), stockavailable bigint, primary key (idproduct)) engine=InnoDB
alter table shoppingdb.cart add constraint FKj5b3osvko2sibhlrxwinq6s9a foreign key (id) references shoppingdb.customers (id)
alter table shoppingdb.orders add constraint FKqlf4gt3wiif5nxtwohsjabyi2 foreign key (id) references shoppingdb.customers (id)
create table shoppingdb.cart (idcart bigint not null auto_increment, id bigint not null, primary key (idcart)) engine=InnoDB
create table shoppingdb.customers (id bigint not null auto_increment, password varchar(255), username varchar(255), primary key (id)) engine=InnoDB
create table shoppingdb.orders (idorder bigint not null auto_increment, ordered datetime(6), total decimal(19,2), id bigint not null, primary key (idorder)) engine=InnoDB
create table shoppingdb.product (idproduct bigint not null auto_increment, price decimal(19,2), productname varchar(255), stockavailable bigint, primary key (idproduct)) engine=InnoDB
alter table shoppingdb.cart add constraint FKj5b3osvko2sibhlrxwinq6s9a foreign key (id) references shoppingdb.customers (id)
alter table shoppingdb.orders add constraint FKqlf4gt3wiif5nxtwohsjabyi2 foreign key (id) references shoppingdb.customers (id)
