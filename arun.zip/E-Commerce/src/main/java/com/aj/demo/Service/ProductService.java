package com.aj.demo.Service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aj.demo.Dao.ProductDao;
import com.aj.demo.model.Product;

@Service
@Transactional
public class ProductService {
@Autowired
ProductDao productdao;

	public List<Product> showproduct() {
		// TODO Auto-generated method stub
		return productdao.findAll();
	}

	public Optional<Product> showproductbyid(Long idproduct) {
		// TODO Auto-generated method stub
		return productdao.findById(idproduct);
	}

	public void insertproduct(Product product) {
	    productdao.save(product);
		// TODO Auto-generated method stub
		
	}

	public void deletefromproduct(Long idproduct) {
		// TODO Auto-generated method stub
		productdao.deleteById(idproduct);
		
	}

	public void updateproduct(Product product, Long idproduct) {
		Product p=productdao.getOne(idproduct);
		p.setName(product.getName());
		p.setDescription(product.getDescription());
		p.setQuantity(product.getQuantity());
		p.setUnitPrice(product.getUnitPrice());
		productdao.save(p);
		// TODO Auto-generated method stub
		
	}


	
	
}
