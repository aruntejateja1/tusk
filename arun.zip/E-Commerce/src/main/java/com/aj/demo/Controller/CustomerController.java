package com.aj.demo.Controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aj.demo.Dao.CartDao;
import com.aj.demo.Dao.CustomerDao;
import com.aj.demo.Service.CustomerService;
import com.aj.demo.model.Customer;



@RestController
public class CustomerController {
	@Autowired
	CustomerService customerservice;
	@Autowired
	CustomerDao customerdao;
	


	@PostMapping("/users")
	public  ResponseEntity<String> adduser(@RequestBody Customer customer) 
			throws NoSuchAlgorithmException{
		List<Customer> customer1=customerdao.findAll();
		System.out.println(customer1.stream().filter(n->customer.getUsername().equals(n.getUsername())).findAny().isPresent());
		if(customer1.stream().filter(n->customer.getUsername().equals(n.getUsername())).findAny().isPresent())
		{
			return new ResponseEntity<>( "User already exists",  HttpStatus.BAD_REQUEST);

		}
		System.out.println(customer.getUsername());
		 customerservice.save(customer);
		return new ResponseEntity<String> ( "User added",HttpStatus.OK);
	}
	
	@GetMapping("/user")
	public List<Customer> user() {
		return customerservice.findAll();
	}
	
	@GetMapping("/user/{id}")
	public Optional<Customer> individualuser(@PathVariable Long id) {
		return customerservice.findById(id);
	}
	

}
