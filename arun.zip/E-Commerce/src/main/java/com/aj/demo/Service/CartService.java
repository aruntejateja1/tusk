package com.aj.demo.Service;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aj.demo.Dao.CartDao;
import com.aj.demo.Dao.CustomerDao;
import com.aj.demo.Dao.ProductDao;
import com.aj.demo.model.Cart;
import com.aj.demo.model.CartModel;
import com.aj.demo.model.Customer;
import com.aj.demo.model.Product;


@Service
@Transactional
public class CartService {
@Autowired
CartDao cartdao;
@Autowired
CustomerDao customerdao;
@Autowired
ProductDao productdao;
@Autowired
JdbcTemplate jdbc;
	public List<Cart> getcartbyuserid(Long id) {
	    Optional<Customer> customerlist=customerdao.findById(id);
	    List<Cart> cartlist=new ArrayList<>();
	    cartdao.findAll().stream().filter(n->n.getCustomer().getId().equals(customerlist.get().getId())).collect(Collectors.toList()).forEach(cartlist::add);	
	    return cartlist;
	}

	public void save(Long id, CartModel cartmodel) {
		List<Product> product=productdao.findById(cartmodel.getProductId()).stream().collect(Collectors.toList());
		product.stream().map(e->{
			e.setQuantity(product.get(0).getQuantity()-cartmodel.getQuantity());
			return e;
			}).collect(Collectors.toList());  
		List<Cart> cart=new ArrayList<>();
		cart.add(new Cart( customerdao.getOne(id), product.get(0), cartmodel.getQuantity(), cartmodel.getQuantity()*product.get(0).getUnitPrice(), new Date()));
		cartdao.saveAll(cart);	
	}
	 public Cart updateProduct(CartModel cartmodel, Long id,Long iditemno) {
		    System.out.println(iditemno);
	        Cart updateitem = cartdao.getOne(iditemno);
	        List<Product> product=productdao.findById(cartmodel.getProductId()).stream().collect(Collectors.toList());
	        product.stream().map(e->{
				e.setQuantity(product.get(0).getQuantity()-cartmodel.getQuantity()+updateitem.getQuantity());
				return e;
				}).collect(Collectors.toList()); 
	        
	        updateitem.setProduct(product.get(0));
	        updateitem.setQuantity(cartmodel.getQuantity());
	        updateitem.setAmount(updateitem.getProduct().getUnitPrice() * cartmodel.getQuantity());
	        return cartdao.save(updateitem);
	    }

	public List<Cart> getcart() {
		return cartdao.findAll();
	}

	

	public void deletefromcart(Long iditemno, Long id) {
		
		Cart updateitem=cartdao.getOne(iditemno);
	        List<Product> product=productdao.findById(updateitem.getProduct().getIdproduct()).stream().collect(Collectors.toList());
	        product.stream().map(e->{
				e.setQuantity(product.get(0).getQuantity()+updateitem.getQuantity());
				return e;
				}).collect(Collectors.toList());  
	        updateitem.setProduct(product.get(0));
	     
		cartdao.deleteById(iditemno);
		
	}


	

}
