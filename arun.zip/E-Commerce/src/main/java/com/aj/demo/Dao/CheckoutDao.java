package com.aj.demo.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aj.demo.model.Checkout;
@Repository
public interface CheckoutDao extends JpaRepository<Checkout, Long> {

	
}
