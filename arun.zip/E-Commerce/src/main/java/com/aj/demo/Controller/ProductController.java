package com.aj.demo.Controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aj.demo.Dao.ProductDao;
import com.aj.demo.Service.ProductService;
import com.aj.demo.model.Customer;
import com.aj.demo.model.Product;



@RestController
public class ProductController {
	@Autowired
	ProductService productservice;
	@Autowired
	ProductDao productdao;
	@GetMapping("/product")
	public List<Product> showproduct() {
		return productservice.showproduct();
	}
	@GetMapping("/product/{idproduct}")
	public Optional<Product> showproductbyid(@PathVariable Long idproduct) {
		return productservice.showproductbyid(idproduct);
	}
	
	@PostMapping("/products")  
	public ResponseEntity<String> createProduct(@RequestBody Product product)      
	{
		List<Product> product1=productdao.findAll(); 
	
		if(	product1.stream().filter(n->product.getName().equals(n.getName())).findAny().isPresent())
		{
			return new ResponseEntity<>( "Product already exists",  HttpStatus.BAD_REQUEST);

		}
		productservice.insertproduct(product);
 
		return ResponseEntity.ok("Product added successfully"); 
	}
	
	@PutMapping("/product/update/{idproduct}")  
	public ResponseEntity<String> updateProduct(@RequestBody Product product,@PathVariable Long idproduct)      
	{
		productservice.updateproduct(product,idproduct);
		return ResponseEntity.ok("Product updated successfully for productid: "+idproduct); 
	} 
	
	@DeleteMapping("/product/delete/{idproduct}")
	public ResponseEntity<String> deleteproduct(@PathVariable Long idproduct)
	{
		productservice.deletefromproduct(idproduct);
		return ResponseEntity.ok("Deleted the itemno: " +idproduct );
	}

}
