package com.aj.demo.Service;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aj.demo.Dao.CustomerDao;
import com.aj.demo.model.Cart;
import com.aj.demo.model.Customer;


@Service
@Transactional
public class CustomerService  {
@Autowired
	private CustomerDao customerdao;

	public void save(Customer customer) {
		
	Customer c=new Customer();
	c.setUsername(customer.getUsername());
	c.setPassword(customer.getPassword());
		customerdao.save(customer);	
	}

	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return customerdao.findAll();
	}

	public Optional<Customer> findById(Long id) {
		// TODO Auto-generated method stub
		return customerdao.findById(id);
	}
	





	
}
