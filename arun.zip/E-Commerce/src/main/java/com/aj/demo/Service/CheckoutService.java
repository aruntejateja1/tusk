package com.aj.demo.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aj.demo.Dao.CartDao;
import com.aj.demo.Dao.CheckoutDao;
import com.aj.demo.model.Cart;
import com.aj.demo.model.Checkout;

@Service
@Transactional
public class CheckoutService {
	@Autowired
	CheckoutDao checkoutdao;
	@Autowired
	CartDao cartdao;

	public List<Checkout> get(Long id, Long idorder) {
		List<Checkout> checkout=new ArrayList<>();
		Double totalprice=cartdao.findAll().stream().filter(n->n.getCustomer().getId()==id).collect(Collectors.summingDouble(n->n.getAmount()));
		System.out.println(totalprice);  
		checkout.add(new Checkout(idorder, cartdao.findAll().stream().filter(n->n.getCustomer().getId()==id).collect(Collectors.toList()),totalprice));
		
		return checkout;
	}
	
	

}
