package com.aj.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.sun.istack.NotNull; 

@Entity
@Table(name = "cart_table", catalog = "shoppingdb")
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "iditemno")
	private Long iditemno;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "customer_id")
	private Customer customer;
 
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "product_id")
	private Product product;

	@Column(name = "quantity")
	@NotNull
	private Integer quantity;

	@Column(name = "amount")
	private Double amount;


	@Column(name = "date")
	private Date date;

	public Cart() {

	}
 
	public Cart( Customer customer, Product product, Integer quantity, Double amount, Date date) {
		super();
		this.customer = customer;
		this.product = product;
		this.quantity = quantity;
		this.amount = amount;
		this.date = date;
	}


	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Long getIditemno() {
		return iditemno;
	}

	public void setIditemno(Long iditemno) {
		this.iditemno  = iditemno;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public Integer getQuantity() {
		return quantity;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

 
	@Override
	public String toString() {
		return "Cart [iditemno=" + iditemno + ", customer=" + customer + ", product=" + product + ", quantity="
				+ quantity + ", amount=" + amount + ", date=" + date + "]";
	}

}
