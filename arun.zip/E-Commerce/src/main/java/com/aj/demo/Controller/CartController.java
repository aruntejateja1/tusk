package com.aj.demo.Controller;

import java.net.URISyntaxException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aj.demo.Dao.CartDao;
import com.aj.demo.Dao.CheckoutDao;
import com.aj.demo.Dao.ProductDao;
import com.aj.demo.Service.CartService;
import com.aj.demo.Service.CheckoutService;
import com.aj.demo.model.Cart;
import com.aj.demo.model.CartModel;
import com.aj.demo.model.Checkout;
import com.aj.demo.model.Product;

@RestController
public class CartController {

	@Autowired
	CartService cartservice;
	@Autowired
	CartDao cartdao;
	@Autowired
	ProductDao productdao;
	@Autowired
	CheckoutService checkoutservice;

	@PostMapping("/user/{id}/addtocart")
	public ResponseEntity<String> create(@PathVariable Long id, @RequestBody CartModel cartmodel) {
		// Long iditemno=id;
		List<Cart> cart1 = cartdao.findAll();
		if (!(cart1.stream()
				.filter(n -> n.getProduct().getIdproduct() == cartmodel.getProductId() && n.getCustomer().getId() == id)
				.collect(Collectors.toList()).isEmpty())) {
			return new ResponseEntity<>("Product already exists in cart", HttpStatus.BAD_REQUEST);

		}
		 List<Product> product=productdao.findById(cartmodel.getProductId()).stream().collect(Collectors.toList());
		  if( product.get(0).getQuantity()<cartmodel.getQuantity())
	        {
	        	return new ResponseEntity<>("Required stock not available", HttpStatus.BAD_REQUEST);
	        }
		if (cartmodel.getQuantity() <= 0) {
			return new ResponseEntity<>("Quantity should be greater than 1", HttpStatus.BAD_REQUEST);
		}
		cartservice.save(id, cartmodel);
		return ResponseEntity.ok("Product added to Cart");
	}

	@PutMapping("/user/{id}/updateitem/{iditemno}")
	public ResponseEntity<String> updateProductItem(@RequestBody CartModel cartmodel, @PathVariable Long id,
			@PathVariable Long iditemno) {
		  Cart updateitem = cartdao.getOne(iditemno);
	       
	        System.out.println(updateitem.getQuantity());
	        System.out.println(cartmodel.getQuantity());
	        if( updateitem.getQuantity()<cartmodel.getQuantity())
	        {
	        	return new ResponseEntity<>("Required stock not available", HttpStatus.BAD_REQUEST);
	        }
		 cartservice.updateProduct(cartmodel, id, iditemno);
		 return ResponseEntity.ok("Cart updated");
	}

	@DeleteMapping("/user/{id}/deleteitem/{iditemno}")
	public ResponseEntity<String> deleteproduct(@PathVariable Long iditemno, @PathVariable Long id) {
		cartservice.deletefromcart(iditemno, id);
		return ResponseEntity.ok("Deleted the itemno: " + iditemno);
	}

	@GetMapping("/user/{id}/cart")
	public List<Cart> cartbyid(@PathVariable Long id) {
		return cartservice.getcartbyuserid(id);
	}

	@GetMapping("/user/cart")
	public List<Cart> cart() {
		return cartservice.getcart();
	}
	
	@GetMapping("/user/{id}/checkout")
	public List<Checkout> checkout(@PathVariable Long id)
	{
		Long idorder=id;
		return checkoutservice.get(id,idorder);
		
	}

}
