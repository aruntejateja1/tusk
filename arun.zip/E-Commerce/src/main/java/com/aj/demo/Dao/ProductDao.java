package com.aj.demo.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aj.demo.model.Product;

public interface ProductDao extends JpaRepository<Product, Long> {

}
