package com.aj.demo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ordertable", catalog = "shoppingdb")
public class Checkout {
	@Id
	private Long idorder;
	@OneToMany
	private List<Cart> cart=new ArrayList<>();
	private Double totalprice;
	
public Checkout()
{
	
}



public Checkout(Long idorder, List<Cart> cart, Double totalprice) {
	super();
	this.idorder = idorder;
	this.cart = cart;
	this.totalprice = totalprice;
}



public Double getTotalprice() {
	return totalprice;
}



public void setTotalprice(Double totalprice) {
	this.totalprice = totalprice;
}



public Long getIdorder() {
	return idorder;
}

public void setIdorder(Long idorder) {
	this.idorder = idorder;
}

public List<Cart> getCart() {
	return cart;
}

public void setCart(List<Cart> cart) {
	this.cart = cart;
}


}
