package com.Bank.Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.Bank.Model.AccountModel;
import com.Bank.Services.LoginService;

@Controller
@RequestMapping(method = { RequestMethod.POST, RequestMethod.GET })
public class LoginController {

	boolean pass_wrong = false;

	AccountModel account1 = null;

	@PostMapping("userLogin")
	public String loginPage() {
		return "userLogin";
	}

	@PostMapping("/accountcheck")
	public String getAccountByUsername(@ModelAttribute("Login") AccountModel account, String username, String password,
			Model model) throws Throwable {

		System.out.println(username + "user" + password);

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinebankingsystem", "root",
					"root");

			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery(
					"select * from account where username ='" + username + "'" + "and password='" + password + "'");

			if (!rs.isBeforeFirst()) {
				model.addAttribute("isPassOK", "No");

			} else {
				while (rs.next()) {
					pass_wrong = true;

					account1 = new AccountModel();

					account1.setAccount_no(rs.getString(1));
					account1.setFirst_name(rs.getString(2));
					account1.setLast_name(rs.getString(3));
					account1.setAddress(rs.getString(4));
					account1.setCity(rs.getString(5));
					account1.setBranch(rs.getString(6));
					account1.setZip(rs.getString(7));
					account1.setUsername(rs.getString(8));
					account1.setPassword(rs.getString(9));
					account1.setPhone_number(rs.getString(10));
					account1.setEmail(rs.getString(11));
					account1.setAccount_type(rs.getString(11));
					account1.setReg_date(rs.getString(12));
					
					

					ResultSet rs1 = st
							.executeQuery("select * from amount where account_no ='" + account1.getAccount_no() + "'");

					while (rs1.next()) {
						account1.setAmount(rs1.getInt(2));

					}
					
					return"";

				}
			}
		} catch (NullPointerException e) {
			// TODO: handle exception
			
			return "userLogin";

		}

		model.addAttribute("Accountno", account1.getAccount_no());
		model.addAttribute("Name",account1.getLast_name()+account1.getFirst_name());
		return "accountcheck";
	}
}
