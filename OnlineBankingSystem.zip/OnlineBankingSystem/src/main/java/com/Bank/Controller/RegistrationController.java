package com.Bank.Controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.Bank.Model.AccountModel;

@Controller
@RequestMapping(method = { RequestMethod.POST, RequestMethod.GET })
public class RegistrationController {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@PostMapping("/registrationProcess")
	public String accountRegistration() {
		return "create_account";

	}

	@PostMapping("regProcess")
	public String submitDatabaseService(@Valid @ModelAttribute("account") AccountModel account, BindingResult result,
			Model model) {
		try {

			String x = account.getPhone_number();
			String y = x.substring(4, 10);

			String Z = account.getFirst_name().substring(0, 3);

			String account_no = Z + y;

			account.setAccount_no(account_no);

			// getting current date
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String reg_date = df.format(new Date());

			account.setReg_date(reg_date);

			if (result.hasErrors()) {
				return "create_account";
			}
			{
				jdbcTemplate.update("insert into account values(?,?,?,?,?,?,?,?,?,?,?,?,?)", account.getAccount_no(),
						account.getFirst_name(), account.getLast_name(), account.getAddress(), account.getCity(),
						account.getBranch(), account.getZip(), account.getUsername(), account.getPassword(),
						account.getPhone_number(), account.getEmail(), account.getAccount_type(),
						account.getReg_date());
				
				jdbcTemplate.update("insert into amount values(?,?)", account.getAccount_no(),account.getAmount());

				model.addAttribute("Account", account_no);

				model.addAttribute("Amount", account.getAmount());

				model.addAttribute("Name", (account.getFirst_name() + " " + account.getLast_name()));

				return "accountReg_progress";
			}
		} catch (Exception e) {

			model.addAttribute("Error", "Account already exists");

			return "create_account";
		}
	}

}
