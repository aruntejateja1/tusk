package com.Bank.Services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.Bank.Model.AccountModel;

@Service
public class LoginService {

	String Username, Password;

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<AccountModel> getUserByUsername(@ModelAttribute("Login") AccountModel account, String username,
			String password) {

		List<AccountModel> account1 = new ArrayList<AccountModel>();

		account1 = jdbcTemplate.query(
				"select * from account where username ='" + username + "'" + "and password='" + password + "'",
				new RowMapper<AccountModel>() {

					@Override
					public AccountModel mapRow(ResultSet rs, int rowNum) throws SQLException {

						AccountModel account1 = new AccountModel();

						account1.setAccount_no(rs.getString(1));
						account1.setFirst_name(rs.getString(2));
						account1.setLast_name(rs.getString(3));
						account1.setAddress(rs.getString(4));
						account1.setCity(rs.getString(5));
						account1.setBranch(rs.getString(6));
						account1.setZip(rs.getString(7));
						account1.setUsername(rs.getString(8));
						account1.setPassword(rs.getString(9));
						account1.setPhone_number(rs.getString(10));
						account1.setEmail(rs.getString(11));
						account1.setAccount_type(rs.getString(11));
						account1.setReg_date(rs.getString(12));

						return account;
					}

				});

		account1 = jdbcTemplate.query("select * from amount where account_no='" + account.getAccount_no() + "'",
				new RowMapper<AccountModel>() {

					@Override
					public AccountModel mapRow(ResultSet rs, int rowNum) throws SQLException {

						AccountModel account1 = new AccountModel();

						account1.setAmount(rs.getInt(2));
						return account;
					}

				});

		return account1;

	}

}
