package com.example.demo;

public class Approve {

	private String approveType;

	public String getApproveType() {
		return approveType;
	}

	public void setApproveType(String approveType) {
		this.approveType = approveType;
	}
	
}
