package com.vTrack.Model;

public class VaccineDetails {

	private String vaccineName;
	private long vaccineCost;
	private int quantityLeft;
	private int quantitySold;
	private String status;
	private String q;
	
	private String location;
	
	

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getQ() {
		return q;
	}

	public void setQ(String q) {
		this.q = q;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVaccineName() {
		return vaccineName;
	}

	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}

	public long getVaccineCost() {
		return vaccineCost;
	}

	public void setVaccineCost(long vaccineCost) {
		this.vaccineCost = vaccineCost;
	}

	public int getQuantityLeft() {
		return quantityLeft;
	}

	public void setQuantityLeft(int quantityLeft) {
		this.quantityLeft = quantityLeft;
	}

	public int getQuantitySold() {
		return quantitySold;
	}

	public void setQuantitySold(int quantitySold) {
		this.quantitySold = quantitySold;
	}

}
