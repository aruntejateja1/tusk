package com.vTrack.Model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Login {
	
	@NotBlank(message = "UserName cannot be empty")
	@Size(min = 5, max=20,message = "Username should me atleast 5 Characters and max 20 characters")
	private String username;
	@NotBlank(message = "Password cannot be empty")
	@Pattern(regexp="(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,}", message="password should contain one Uppercse, Lowercase, numbers and special character")
	@Size(min=6, message="Minimum 6 Characters")
	private String password;
	private String userrole;
	@NotBlank(message="Name cannot be empty")
	private String name;
	public String getUsername() {
		return username;
	}
	
	private String q;
	
	
	public String getQ() {
		return q;
	}
	public void setQ(String q) {
		this.q = q;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserrole() {
		return userrole;
	}
	public void setUserrole(String userrole) {
		this.userrole = userrole;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

}
