package com.vTrack.Model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class adminRegister {
	@NotBlank(message = "Enter your Full name")
	private String name;
	@NotEmpty(message = "Enter your location")
	private String location;
	@NotBlank(message = "UserName cannot be empty")
	@Size(min = 5, max = 20, message = "Username should me atleast 5 Characters and max 20 characters")
	private String username;

	@NotBlank(message = "Password cannot be empty")
	@Pattern(regexp = "(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,}", message = "password should contain one Uppercse, Lowercase, numbers and special character")
	@Size(min = 6, message = "Minimum 6 Characters")
	private String password;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
