package com.vTrack.Controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vTrack.Dao.JdbcConnect;
import com.vTrack.Model.UserRegister;
import com.vTrack.Model.VaccineDetails;

@Controller
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class AdminAccessController {

	@Autowired
	JdbcTemplate template;
	int vSold;
	String status,vName;
	

	List<UserRegister> checkData = new ArrayList<UserRegister>();

	@PostMapping("/adminAccessPage")
	public String AdminAccessPage() {
		return "AdminAccessPage";
	}

	@PostMapping("/checkdata")
	public String listuserdetails(@ModelAttribute("checkdata") UserRegister checkdata1, String location,
			String agegroup, Model model) {

		return "UserData";
	}

	@PostMapping("/deleteUserData")
	public String deleteUser(@ModelAttribute("checkdata") UserRegister user, String username) {

		template.update("delete from user where username=?", username);

		return "UserData";

	}

	@PostMapping("/addNewVaccine")
	public String AddNewVaccine(@ModelAttribute("vaccine") VaccineDetails vaccine) {

		return "AddNewVaccine";

	}

	@PostMapping("/addNewVaccine2")
	public String AddNewVaccine2(@ModelAttribute("vaccine") VaccineDetails vaccine,String vaccineName,Model model) {
		try {

		vSold = 0;
		status = "Available";
		
		JdbcConnect connect = new JdbcConnect();
		Connection con = connect.getConnection();

		Statement st = con.createStatement();

		ResultSet rs = st.executeQuery("select * from vaccine");

		while (rs.next()) {
			vName= rs.getString("vName");
			
		}
		rs.close();

		if (vName.equals(vaccineName)) {

			System.out.println(vaccineName + "Raj");

			model.addAttribute("Error", "Vaccine already exists");
			return "AddNewVaccine";
		}

		template.update("insert into vaccine values(?,?,?,?)", vaccine.getVaccineName(), vaccine.getVaccineCost(),
				vaccine.getQuantityLeft(), status);
		model.addAttribute("Error", "Vaccine added Successfully");

		return "AddNewVaccine";

	}catch (Exception e) {
		// TODO: handle exception
		model.addAttribute("Error", "vaccine already exists");
		
		System.out.println(e);
	}
		
		return "AddNewVaccine";

}
}
