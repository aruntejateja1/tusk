package com.vTrack.Controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vTrack.Dao.JdbcConnect;
import com.vTrack.Model.UserRegister;

@Controller
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class UserRegistrationController {

	String Username;

	long MobileNumber;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@RequestMapping("/userregisterpage")
	public String userRegister(@ModelAttribute("Register") UserRegister Register) {

		return "UserRegister";

	}

	@PostMapping("/regprocess")
	public String RegistrationSuccess(@ModelAttribute("Register") UserRegister Register, BindingResult result,
			String agegroup, String username, Long number, Model model) {

		try {

			long x = Register.getNumber();
			String y = Long.toString(x).substring(5, 10);

			String Z = Register.getFirstname().substring(0, 3).toUpperCase();

			String RegistrationNo = Z + y;

			Register.setRegNo(RegistrationNo);

			// getting current date
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String reg_date = df.format(new Date());

			Register.setRegDate(reg_date);

			JdbcConnect connect = new JdbcConnect();
			Connection con = connect.getConnection();

			Statement st = con.createStatement();

			ResultSet rs = st.executeQuery("select * from user");

			while (rs.next()) {
				Username = rs.getString(6);
				MobileNumber = rs.getLong(5);
			}
			rs.close();

			if (username.equals(Username)) {

				System.out.println(Username + "Raj");

				model.addAttribute("Error", "UserId is already exists");
				return "UserRegister";
			}

			else if (number.equals(MobileNumber)) {

				model.addAttribute("Error", "Contact Number is already exists");
				return "UserRegister";

			}

			else {
				jdbcTemplate.update("insert into user values(?,?,?,?,?,?,?,?,?,?,?)", Register.getFirstname(),
						Register.getLastname(), Register.getAgegroup(), Register.getGender(), Register.getNumber(),
						Register.getUsername(), Register.getPassword(), Register.getAddress(), Register.getRegDate(),
						Register.getRegNo(),Register.getLocation());

				model.addAttribute("RegistrationNo", RegistrationNo);

				model.addAttribute("Name", (Register.getFirstname() + " " + Register.getLastname()));
				model.addAttribute("username", username);
				model.addAttribute("location", Register.getLocation());

				return "RegisterSuccessfull";
			}
		} catch (Exception e) {

			System.out.println(e);

			model.addAttribute("Error", "User already exists");

			return "Null";
		}
	}

}
