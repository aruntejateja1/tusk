package com.vTrack.Controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vTrack.Dao.JdbcConnect;
import com.vTrack.Model.adminRegister;

@Controller
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class AdminRegistration {

	String Username, Location, Name;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@PostMapping("/adminregisterpage")
	public String adminRegister(@ModelAttribute("Register") adminRegister Register) {
		return "AdminRegister";
	}

	@PostMapping("/adminRegProcess")
	public String adminRegistration(@ModelAttribute("Register") adminRegister register, BindingResult result,
			Model model, String username, String location, String name) {

		try {

			JdbcConnect connect = new JdbcConnect();
			Connection conn = connect.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from admin where username='"+username+"'or name='"+name+"'");

			while (rs.next()) {

				Username = rs.getString("username");
				Location = rs.getString("location");
				Name = rs.getString("name");

			}
			System.out.println(Username);
			rs.close();

			if (username.equals(Username)) {
				model.addAttribute("Error", "Username already exists");
				
				return "AdminRegister";
			}
			else if (name.equals(Name)) {
				model.addAttribute("Error", "Name already exists");
				
				return "AdminRegister";
			} 
			
				else {
				jdbcTemplate.update("insert into admin values(?,?,?,?)", register.getUsername(), register.getPassword(),
						register.getName(), register.getLocation());
				model.addAttribute("Name", register.getName());
				model.addAttribute("location", register.getLocation());
				model.addAttribute("username", register.getUsername());
				return"adminRegProcess";
			}

		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}

		return "";
	}

}
