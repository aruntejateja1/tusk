package com.vTrack.Controller;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vTrack.Dao.JdbcConnect;
import com.vTrack.Model.BookAslot;
import com.vTrack.Model.Login;
import com.vTrack.Model.UserRegister;
import com.vTrack.Model.VaccineDetails;

@Controller
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class VaccineAvailController {

	UserRegister user1 = null;

	long vCost;
	int quantity;

	String Name;
	long Number;

	@Autowired
	JdbcTemplate template;

	@PostMapping("/vaccinedata")
	public String vaccinecheck(@ModelAttribute("vaccine") VaccineDetails vaccine, Model model) {

		return "UpdateVaccine";

	}

	@PostMapping("/deleteVaccine")
	public String vaccineDelete(@ModelAttribute("vaccine") VaccineDetails vaccine, Model model, String vName) {

		template.update("delete from vaccine where vName=?", vName);

		return "UpdateVaccine";

	}

	@PostMapping("/updateVaccine")
	public String vaccineUpdate(@ModelAttribute("vaccine") VaccineDetails vaccine, Model model, String vName) {
		try {
			JdbcConnect connect = new JdbcConnect();
			Connection conn = connect.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from vaccine where vName='" + vName + "'");

			while (rs.next()) {

				vCost = rs.getLong("vCost");
				quantity = rs.getInt("quantityLeft");

			}
			rs.close();

			model.addAttribute("vName", vName);
			model.addAttribute("vCost", vCost);
			model.addAttribute("quantity", quantity);

			System.out.println(vName);

			return "EditorUpdateVaccine";
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "null";

	}

	@PostMapping("/bookASlot")
	public String bookaSlot(@ModelAttribute("login") BookAslot book, Model model, String name, Long number) {
		try {

			JdbcConnect connect = new JdbcConnect();
			Connection conn = connect.getConnection();
			Statement st = conn.createStatement();
			String N = name.substring(0, 3);
			String M = number.toString().substring(5, 10);

			ResultSet rs = st.executeQuery("select * from slotbook where name='" + name + "'");

			while (rs.next()) {

				Name = rs.getString("name");
				Number = rs.getLong("number");

			}

			if (name.equals(Name)) {

				model.addAttribute("Error", "Already registered for vaccination");

				return "BookedSuccessfully";

			} else {

				template.update("insert into slotbook values(?,?,?)", book.getLocation(), book.getName(),
						book.getNumber());
				model.addAttribute("Error", "Successfully booked a slot and Your Slot Number :" + N + M);

				return "BookedSuccessfully";

			}

		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
			model.addAttribute("Error", "Already registered for vaccination");
		}
		return "BookedSuccessfully";

	}

	@PostMapping("/updateVaccine2")
	public String EditOrUpdateVaccine(@ModelAttribute("vaccine") VaccineDetails vaccine, Model model) {

		if (vaccine.getVaccineCost() < 0 || vaccine.getQuantityLeft() < 0) {

			model.addAttribute("Error1", "Invalid cost/quantity details");

			return "UpdateVaccine";

		} else {

			template.update("update vaccine set vCost=?,quantityLeft=?,status=? where vName=?",
					vaccine.getVaccineCost(), vaccine.getQuantityLeft(), vaccine.getStatus(), vaccine.getVaccineName());

			model.addAttribute("Error1", vaccine.getVaccineName() + " " + "is updated  Successfully");

			return "UpdateVaccine";
		}

	}

}
