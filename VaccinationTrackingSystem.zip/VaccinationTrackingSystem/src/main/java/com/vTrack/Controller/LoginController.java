package com.vTrack.Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vTrack.Dao.JdbcConnect;
import com.vTrack.Model.Login;

@Controller
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class LoginController {

	@PostMapping("/loginpage")
	public String loginPage(@ModelAttribute("login") Login login) {
		return "Login";
	}

	@PostMapping("/loginprocess")
	public String postLoginPage(@ModelAttribute("login") Login login, Model model, String userrole, String username,
			String password) {

		System.out.println(username + " " + password);

		try {
			JdbcConnect connect = new JdbcConnect();

			Connection con = connect.getConnection();
			Statement st = con.createStatement();

			if (userrole.equals("user")) {

				ResultSet rs = st.executeQuery(
						"select * from user where username='" + username + "' and password='" + password + "'");

				if (rs.next()) {

					String Username = rs.getString("username");
					String Password = rs.getString("password");
					String Name= rs.getString(1) +" "+rs.getString(2);
					
					login.setUsername(Username);
					login.setName(Name);

					System.out.println(Username + " " + Password);

					return "LoginProcess";
				}

				else {

					model.addAttribute("Error", "Invalid login details");
					return "Login";
				}
			}
			
			else if (userrole.equals("admin")) {

				ResultSet rs1 = st.executeQuery(
						"select * from admin where username='" + username + "' and password='" + password + "'");

				if (rs1.next()) {

					String Username = rs1.getString("username");
					String Password = rs1.getString("password");
					String Name= rs1.getString(1) +" "+rs1.getString(2);
					
					login.setUsername(Username);
					login.setName(Name);

					System.out.println("Admin: Username "+Username + " " + Password);

					return "AdminAccessPage";
				}

				else {

					model.addAttribute("Error", "Invalid login details");
					return "Login";
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}

		return "Login";

	}

}
