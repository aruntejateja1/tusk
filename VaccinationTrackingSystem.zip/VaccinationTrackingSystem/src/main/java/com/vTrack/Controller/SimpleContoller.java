package com.vTrack.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vTrack.Model.Login;

import com.vTrack.Model.UserRegister;
import com.vTrack.Model.VaccineDetails;
import com.vTrack.Model.adminRegister;

@Controller
@RequestMapping(method = {RequestMethod.GET,RequestMethod.POST})
public class SimpleContoller {
	
	@PostMapping("/homepage")
	public String homepage() {
		return "Home";

	}
	
	@PostMapping("/about")
	public String about() {
		return "About";
	}
	
	@PostMapping("/logout")
	public String logout(@ModelAttribute("login")Login login) {
		return "Login";
	}
	@PostMapping("/userdata")
	public String userdata(@ModelAttribute("checkdata")UserRegister checkdata) {
		
		return "UserData";
		
	}
	@PostMapping("/updatevaccine")
	public String vaccinedata(@ModelAttribute("vaccine")VaccineDetails vaccine) {
		
		return "UpdateVaccine";
		
	}
	@PostMapping("/vdata")
	public String vaccinedata(@ModelAttribute("login")Login login) {
		
		return "LoginProcess";
		
	}
	@PostMapping("/checkV")
	public String vaccinedata2(@ModelAttribute("login")Login login) {
		
		return "LoginProcess";
		
	}

}
