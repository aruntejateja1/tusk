package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.model.User;
import com.example.demo.repositories.UserRepository;
import com.example.demo.service.UserService;

@Controller
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class UserController {
@Autowired
JdbcTemplate jdbcTemplate;

@Autowired
UserRepository urepo;

@Autowired
UserService uService;


	//add dependencies in pom.xml to see jsp pages in browser
	@GetMapping("index")
	public String home() {
		return "index";
	}
	
	@GetMapping("submit")
	public String home2() {
		return "aftersubmit";
	}
	
	@GetMapping("userLogin2")
	public String userLogin(@ModelAttribute User user2) {
		
		return "userLogin";
		
	}
	


@GetMapping("registration")
public String registerPage(@ModelAttribute User user) {
	return "registration";
}


@PostMapping("registration2")
public String registerUser(@Valid @ModelAttribute User user,BindingResult result,Model model) {
	if(result.hasErrors()) {
		return "registration";
	}

	else {
		return uService.userRegistration(user, model);
	}

}



@PostMapping("uLogin2")
public String userLogin2(String uName, String uPassword, Model model) {
	
	System.out.println(uName);
	return uService.userLogin(uName,uPassword,model);
	

}


@PostMapping("balance")
public String balanceCheck(String uName,Model model) {
	
	return uService.balanceCheck(uName,model);
	
}

@ModelAttribute("getRadios")
public List<String> getUserType() {
	List<String> radios = new ArrayList<>();
	radios.add("Savings Account");
	radios.add("Current Account");

	return radios;
}
 





@PostMapping("/loginprocess")
public String loginProcess(String uName, String uPassword, Model model) {

	try {

		/*
		 * if (uName.equals("arunkohli") && uPassword.equals("Arunkohli@345")) {
		 * 
		 * return "logout";
		 */

		System.out.println(uName);
		return uService.userLogin(uName, uPassword, model);
	}

	catch (Exception e) {
		return "login";// TODO: handle exception
	}
}
/*
 * @PostMapping("withdraw") public String registerPage2(@ModelAttribute User
 * user,Model model,String uName) { model.addAttribute("uName", uName);
 * 
 * 
 * return "withdrawType"; }
 * 
 * @GetMapping("accountChoice") public String accountChoice(@ModelAttribute User
 * user,Model model,String uName) {
 * 
 * return uService.accountChoice(user,model,uName);
 * 
 * 
 * }
 * 
 * 
 * @PostMapping("sWithdrawAmount") public String withdrawAmount(int sBalance,int
 * samount,Model model,String uName) { System.out.println(uName);
 * //System.out.println(samount); //System.out.println(sBalance);
 * 
 * return uService.withdrawAmount(sBalance,samount,model,uName);
 * 
 * 
 * // return "index";
 * 
 * }
 */



/*
 * @GetMapping("index2") public String logOut(HttpServletResponse
 * response,HttpServletRequest request ) {
 * 
 * HttpSession session=request.getSession(); session.invalidate(); return
 * "index";
 * 
 * }
 */




/*
 * @GetMapping("/index2") protected String doPost2(HttpServletRequest request,
 * HttpServletResponse response) throws ServletException, IOException { // TODO
 * Auto-generated method stub response.setContentType("text/html"); PrintWriter
 * out = response.getWriter();
 * out.println("thanq you!!, Your session was destroyed successfully!!");
 * HttpSession session = request.getSession(false); //
 * session.setAttribute("user", null); session.removeAttribute("userr");
 * session.getMaxInactiveInterval(); return "index"; }
 */

/*
 * 
 * @GetMapping("index2") protected String doGet(HttpServletRequest request,
 * HttpServletResponse response) throws ServletException, IOException {
 * response.setContentType("text/Jsp"); PrintWriter out=response.getWriter();
 * 
 * request.getRequestDispatcher(
 * "/OnlineBankingSystem-1/src/main/webapp/view/userAccessPage.jsp").include(
 * request, response);
 * 
 * HttpSession session=request.getSession(); session.invalidate();
 * 
 * out.print("You are successfully logged out!");
 * 
 * out.close(); return "index"; }
 */


}
