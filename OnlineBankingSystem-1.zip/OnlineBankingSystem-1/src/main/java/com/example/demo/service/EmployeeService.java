package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.model.Employee;
import com.example.demo.model.User;
import com.example.demo.repositories.EmployeeRepository;
import com.example.demo.repositories.UserRepository;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository erepo;
	@Autowired 
	UserRepository urepo;
	public String employeeRegistration(@Valid Employee employee, Model model) {
		// TODO Auto-generated method stub
		List<Employee> list=erepo.findAll();
		if(list.stream().filter(i->employee.getEmployeeName().equalsIgnoreCase(i.getEmployeeName())).findAny().isPresent()) {
		model.addAttribute("error","employee name already exists.please enter unique employee name" );
		
		return "registrationEmployee";
	}
		else if(!employee.getBankCode().equals("cts@123")) {
			model.addAttribute("error", "Bank code is wrong");
			return "registrationEmployee";
		}
		else {
			erepo.save(employee);
			model.addAttribute("error","Employee Registration completed Successfully");
			return "aftersubmit";
		}
		
	}
	public String employeeLogin(String eid, String epassword, Model model) {
		// TODO Auto-generated method stub
		
		List<Employee> list=erepo.findAll();
		
		if(!list.stream().filter(i->i.getEmployeeName().equals(eid)).findAny().isPresent()) {
			model.addAttribute("error", "Employee name does not exists");
			
			return "employeeLogin";
		}
		
		
		
		else if(erepo.findById(eid).get().getPassword().equals(epassword)) {
			model.addAttribute("error",erepo.findById(eid).get().getEmployeeName());
			return "employeeAccessPage";
		}
		else {
			model.addAttribute("error","invalid credentials");
			return "employeeLogin";
		}

	}
	
	
	
	public String withdrawAmount(String account, User user, Model model, String uName, int samount) {
		// TODO Auto-generated method stub
		List<User> list=urepo.findAll();
		//System.out.println(list.stream().filter(i->i.getAccountNumber().equals(account)).collect(Collectors.toList()).get(0).getUserName());
		if(list.stream().filter(i->i.getAccountNumber().equals(account)).findAny().isPresent()) {
		String uName2=list.stream().filter(i->i.getAccountNumber().equals(account)).collect(Collectors.toList()).get(0).getUserName();
		User user2=urepo.findById(uName2).get();
		int sBalance=user2.getSavingsAccountBalance();
		int cBalance=user2.getCurrentAccountBalance();
		

		 if(user.getUserType()==null){
			model.addAttribute("error", "Please select Account Type");
			return "employeeWithdrawPage";
		}
		
		 else if(user.getUserType().equals("Savings Account")&&sBalance==0) {
			model.addAttribute("error", "Please select another account type");
			return "employeeWithdrawPage";
		}
		else if(user.getUserType().equals("Current Account")&&cBalance==0) {
			model.addAttribute("error", "Please select another account type");
			return "employeeWithdrawPage";
		}
		
		else if(user.getUserType().equals("Savings Account")) {
		if (samount <= 0) {
			model.addAttribute("error", "invalid amount");
			return "employeeWithdrawPage";
		}
		else if(sBalance>=samount) {
			user2.setSavingsAccountBalance(sBalance-samount);
			//user2.setCurrentAccountBalance(cBalance-samount);
			urepo.save(user2);
			model.addAttribute("error", "amount withdrawn successfully");
			return "aftersubmit";
		}
		else {
			model.addAttribute("error", "Doesn't have Enough Balance");
			return "employeeWithdrawPage";
		}
		}
		
		
		else if(user.getUserType().equals("Current Account")) {
			if (samount <= 0) {
				model.addAttribute("error", "invalid amount");
				return "employeeWithdrawPage";
			}
			else if(cBalance>=samount&&sBalance>=samount) {
				//user2.setSavingsAccountBalance(sBalance-samount);
				user2.setCurrentAccountBalance(cBalance-samount);
				urepo.save(user2);
				model.addAttribute("error", "amount withdrawn successfully");
				return "aftersubmit";
			}
			else if(cBalance>=samount&&sBalance<=samount) {
				user2.setSavingsAccountBalance(0);
				user2.setCurrentAccountBalance(cBalance-samount);
				urepo.save(user2);
				model.addAttribute("error", "amount withdrawn successfully");
				return "aftersubmit";
			}
			else {
				model.addAttribute("error", "Doesn't have Enough Balance");
				return "employeeWithdrawPage";
			}
		}

		}
		
		else {
			model.addAttribute("error", "invalid account number");
			return "employeeWithdrawPage";
		}
		return "index";
		
		
	}
	
	
	
	
	
}
