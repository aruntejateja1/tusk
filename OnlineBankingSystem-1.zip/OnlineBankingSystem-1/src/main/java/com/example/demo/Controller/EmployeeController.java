package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.model.Employee;
import com.example.demo.model.User;
import com.example.demo.repositories.EmployeeRepository;
import com.example.demo.repositories.UserRepository;
import com.example.demo.service.EmployeeService;

@Controller

//very important line for logout
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class EmployeeController {

	@Autowired
	EmployeeService eService;
	@Autowired 
	EmployeeRepository erepo;
	@Autowired 
	UserRepository urepo;

@GetMapping("EmployeeLogin")
public String EmployeeLogin() {
	return "employeeLogin";
}


@GetMapping("registrationEmployee")
public String registerPage2(@ModelAttribute Employee employee) {
	return "registrationEmployee";
}




@PostMapping("employeeRegistration")
public String registerUser(@Valid @ModelAttribute Employee employee,BindingResult result,Model model) {
	if(result.hasErrors()) {
		return "registrationEmployee";
	}

	else {
		return eService.employeeRegistration(employee, model);
	}

}

@PostMapping("employeeLogin")
public String employeeLogin(String eid,String epassword,Model model) {
	System.out.println(eid);
return eService.employeeLogin(eid,epassword,model);	
	
}




@ModelAttribute("getRadios")
public List<String> getUserType(){
	List<String> radios = new ArrayList<>();
	radios.add("Savings Account");
	radios.add("Current Account");

	return radios;
}


@PostMapping("withdraw")
public String registerPage2(@ModelAttribute User user,Model model,String uName) {
	model.addAttribute("uName", uName);

	
	return "employeeWithdrawPage";
}

/*
 * @GetMapping("accountChoice") public String accountChoice(@ModelAttribute User
 * user,Model model,String uName) {
 * 
 * return eService.accountChoice(user,model,uName);
 * 
 * 
 * }
 */


@PostMapping("eWithdrawAmount")
public String withdrawAmount(String account, @ModelAttribute User user,Model model,String uName,int samount) {
	
	return eService.withdrawAmount(account, user,model,uName,samount);
	
	
	
	//return eService.withdrawAmount(sBalance,samount,model,uName);


//	return "index";
	
}











}
