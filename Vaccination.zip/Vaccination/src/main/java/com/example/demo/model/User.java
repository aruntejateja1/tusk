package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;

@Entity
@DynamicInsert
public class User {

	
	@NotBlank(message="Name is mandatory")
	@Pattern(regexp="[a-z A-z]{4,50}",message="userName must be 4 to 50 characters")
	private String fullName;


	@NotBlank(message="aadhaar Number is mandatory")
	@Pattern(regexp="[0-9]{12}",message="account number must be 12 numbers")
	@Id
private String aadharNumber;

	@NotBlank(message="Number is mandatory")
	@Pattern(regexp="[0-9]{10}",message="Contact Number must be 10 numbers")
private String contactNumber;

	@NotBlank(message="Email is mandatory")
	@Pattern(regexp="[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$",message="Email must be in format characters@characters.domain")
private String email;

	@NotBlank(message="Password is mandatory")
	@Pattern(regexp="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%*^]).{6,}",message="Password must contain more than 6 letters with atleast one number,one lowercase and one uppercase and one special character")
private String password;
	
	@NotBlank(message="age is mandatory")
	@Pattern(regexp="[0-9]{10}",message="Contact Number must be 1 to 2 digits")
	private String age;

	
	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getFullName() {
		return fullName;
	}
	
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

public String getContactNumber() {
	return contactNumber;
}

public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}


@Override
public String toString() {
	return "User [fullName=" + fullName + ", aadharNumber=" + aadharNumber + ", contactNumber=" + contactNumber
			+ ", email=" + email + ", password=" + password + ", age=" + age + "]";
}



}
