package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.User;
import com.example.demo.service.UserService;


@Controller
public class UserController {
@Autowired
UserService uService;

	@GetMapping("index")
	public String method() {
		return "index";
	}
	
	@ModelAttribute("getRadios")
	public List<String> getUserType() {
		List<String> radios = new ArrayList<>();
		radios.add("Savings Account");
		radios.add("Current Account");

		return radios;
	}
	@GetMapping("registration")
	public String registerPage(@ModelAttribute User user) {
		return "registration";
	}
	
	
	@GetMapping("userLogin2")
	public String userLogin(@ModelAttribute User user2) {
		
		return "userLogin";
		
	}
	
	
	
	
	@PostMapping("registration2")
	public String registerUser(@Valid @ModelAttribute User user,BindingResult result,Model model) {
		if(result.hasErrors()) {
			return "registration";
		}

		else {
			return uService.userRegistration(user, model);
		}

	}
}
