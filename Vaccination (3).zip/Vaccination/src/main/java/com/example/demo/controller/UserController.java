package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.model.BookVaccination;
import com.example.demo.model.User;
import com.example.demo.model.VaccinationCenter;
import com.example.demo.repositories.BookingRepository;
import com.example.demo.repositories.UserRepository;
import com.example.demo.repositories.VaccineRepository;
import com.example.demo.service.UserService;


@Controller
@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
public class UserController {
@Autowired
UserService uService;
@Autowired
UserRepository urepo;
@Autowired
VaccineRepository vrepo;
@Autowired
BookingRepository brepo;




	@GetMapping("index")
	public String method() {
		return "index";
	}
	
	@ModelAttribute("getRadios")
	public List<String> getUserType() {
		List<String> radios = new ArrayList<>();
		radios.add("Savings Account");
		radios.add("Current Account");

		return radios;
	}
	@GetMapping("registration")
	public String registerPage(@ModelAttribute User user) {
		return "registration";
	}
	
	
	@GetMapping("userLogin2")
	public String userLogin(@ModelAttribute User user2) {
		
		return "userLogin";
		
	}
	
	
	
	
	@PostMapping("registration2")
	public String registerUser(@Valid @ModelAttribute User user,BindingResult result,Model model) {
		if(result.hasErrors()) {
			return "registration";
		}

		else {
			return uService.userRegistration(user, model);
		}

	}
	
	
	@PostMapping("uLogin2")
	public String userLogin2(String uAadhar, String uPassword, Model model) {
		
		System.out.println(uAadhar);
		return uService.userLogin(uAadhar,uPassword,model);
		

	}

	
	@PostMapping("searchPage")
	public String SearchPage(String location,String uAadhar,Model model,HttpServletRequest request, HttpServletResponse response)
	{
		
		/*
		 * HttpSession session = request.getSession(); session.setAttribute("uAadhar",
		 * uAadhar);
		 */
		
		  final String name=uAadhar; 
		  System.out.println(name);
		 
		System.out.println(uAadhar);

		model.addAttribute("uAadhar",uAadhar);
		return "searchPage";
	}
	
	
	@GetMapping("customerregistration")
	public String CustomerRegistration(String uAadhar,Model model,String vName,String vType)
	{

		model.addAttribute("vName", vName);
	//	model.addAttribute("uName",vType);
	//	model.addAttribute("vid", vid);
		System.out.println(uAadhar);
		System.out.println(vName);
		System.out.println(vType);
	//	System.out.println(vid);
		return "customerBooking";
		
	}
	
	
	
	@PostMapping("bookService")
	public String book(String vName,String dateslot,String timeslot,String uAadhar,Model model) {
		Date date=new Date();
		System.out.println(date);
		System.out.println(uAadhar);
System.out.println(vName);

if(urepo.findById(uAadhar).isEmpty()) {
	model.addAttribute("error", "Given Aadhar number is not registered ");
	return "customerBooking";
}


if(brepo.findById(uAadhar).isPresent()) {
	model.addAttribute("error", "already booked the vaccine");
	return "customerBooking";
}
String age=vrepo.findById(vName).get().getAge().substring(0, 2);
//converting string to integer
int i=Integer.parseInt(age);  
int j=Integer.parseInt(urepo.findById(uAadhar).get().getAge());  
if(j<i) {
	model.addAttribute("error", "Age must be greater than "+i);
	return "customerBooking";
}



BookVaccination bvc=new BookVaccination();
bvc.setAadharNumber(uAadhar);
bvc.setvName(vName);
bvc.setAge(urepo.findById(uAadhar).get().getAge());
bvc.setDateslot(dateslot);
bvc.setFullName(urepo.findById(uAadhar).get().getFullName());
bvc.setTimeslot(timeslot);
bvc.setvAddress(vrepo.findById(vName).get().getvAddress());
bvc.setVaccineName(vrepo.findById(vName).get().getVaccineName());
String contactNumber=urepo.findById(uAadhar).get().getContactNumber();
bvc.setContactNumber(contactNumber);


String x =urepo.findById(uAadhar).get().getAadharNumber().substring(6, 12);


String z =urepo.findById(uAadhar).get().getContactNumber().substring(0, 4) ;

String appointment_no = x+z;

bvc.setAppointmentNumber(appointment_no);
brepo.save(bvc);
VaccinationCenter vc=vrepo.findById(vName).get();
int vAvailable2=vc.getvAvailable()-1;
if(vAvailable2<=0) {
	model.addAttribute("error", "Not enough vaccines available.Please go back and chose another vaccination center");
	return "aftersubmit";
}
vc.setvAvailable(vAvailable2);
vrepo.save(vc);


model.addAttribute("error", "Appointment Booked Successfully");
		return "aftersubmit";
		
		
	}

	
	
	
	@PostMapping("appointment")
	public String appointment(String uAadhar,Model model,String uName) {
		if(brepo.findById(uAadhar).isEmpty()) {
			model.addAttribute("error","No Appointment Booked. Go Back and Book An Appointment");
			return "aftersubmit";
		}
		model.addAttribute("uAadhar", uAadhar);

		model.addAttribute("error", uName);
		System.out.println(uAadhar);
		System.out.println(uName);
		return "BookingDetails";
	}
	
	
	@PostMapping("cancelAppointment")
	public String cancelAppointment(String uAadhar,Model model) {
		if(brepo.findById(uAadhar).isPresent()) {
		brepo.deleteById(uAadhar);
		
		model.addAttribute("error", "Appointment Cancelled");
		return "aftersubmit";
		}
		else {
			model.addAttribute("error", "No Appointment was booked.Go back and schedule your Appointment");
			return "aftersubmit";
		}
	}
	
	@PostMapping("vLogin")
	public String vCenterLogin() {
		return "vCenterLogin";
	}
	
	@PostMapping("vLogin2")
	public String vCenterLogin2(String vCode,String vPassword,Model model) {
		  List<VaccinationCenter> list=vrepo.findAll();
		  
		  if(!list.stream().filter(i->i.getvCode().equals(vCode)).findAny(). isPresent()) { 
			  model.addAttribute("error", "wrong vaccination center code");
		
		return "vCenterLogin";
	}
		  
		  else if(list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getvPassword().equals(vPassword)) {
			  String vCenterName=list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getvName();
			  model.addAttribute("vCenterName", vCenterName);
			  String age=list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getAge();
			  model.addAttribute("age", age);
			 int vAvailable= list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getvAvailable();
			 model.addAttribute("vAvailable", vAvailable);
			
			 
			  int cost=list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getCost();
			  model.addAttribute("cost", cost);
			  String contact=list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getvContact();
			  model.addAttribute("contact",contact);
			  
			  String vName=list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getVaccineName();
			  model.addAttribute("vName", vName);
			  
			  String stime=list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getvStime();
			  model.addAttribute("stime", stime);
			  
			  String etime=list.stream().filter(i->i.getvCode().equals(vCode)).findAny().get().getvEtime();
			  model.addAttribute("etime", etime);
			 return "vCenterPage";
		 }
		  else  {
			  model.addAttribute("error", "Wrong Password");
				
				return "vCenterLogin";
			 }
		
	}
	
	
	@PostMapping("updateInfo")
	public String updateInformation(String vCenterName,String age,int cost,int vAvailable,String contact, String vName,String stime,String etime,Model model) {
	VaccinationCenter vc=vrepo.findById(vCenterName).get();
	vc.setVaccineName(vName);
	vc.setAge(age);
	vc.setCost(cost);
	vc.setvStime(stime);
	vc.setvEtime(etime);
	vc.setvContact(contact);
	vc.setvName(vCenterName);
	vc.setvAvailable(vAvailable);
	vrepo.save(vc);
		 model.addAttribute("error","Details Updated Succesfully");
		return "aftersubmit";
	}
	
	
	@PostMapping("viewDetails")
	public String viewDetails(String vDetails,Model model) {
		model.addAttribute("vDetails", vDetails);
		System.out.println(vDetails);
		return "viewDetails";
		
	}
}
