package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.model.User;
import com.example.demo.repositories.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository urepo;
	public String userRegistration(User user,Model model){
		
		List<User> list=urepo.findAll();
			if(list.stream().filter(i->user.getAadharNumber().equalsIgnoreCase(i.getAadharNumber())).findAny().isPresent()) {
			model.addAttribute("error","Already Registered with given AAdhar Number" );	
			return "registration";
			
		}
			else if(list.stream().filter(i->user.getContactNumber().equalsIgnoreCase(i.getContactNumber())).findAny().isPresent()) {
				model.addAttribute("error","Already registered with given contact number" );	
				return "registration";
			}
			
			
			else {
				urepo.save(user);
				model.addAttribute("error","Registration Done Successfully");
				return "aftersubmit";
			}
		
		
			
	
		
	}
	
	
	public String userLogin(String uAadhar, String uPassword, Model model) { //
	
	  
	  List<User> list=urepo.findAll();
	  
	  if(!list.stream().filter(i->i.getAadharNumber().equals(uAadhar)).findAny(). isPresent()) { 
		  model.addAttribute("error", "Aadhar number does not exists");
	  
	  return "userLogin";
	  }
	  
	  
	  
	  else if(urepo.findById(uAadhar).get().getPassword().equals(uPassword)) {
	  model.addAttribute("error", urepo.findById(uAadhar).get().getFullName());
	  model.addAttribute("uAadhar", urepo.findById(uAadhar).get().getAadharNumber());
	  
	  return "userAccessPage";
	  } 
	  else {
		  model.addAttribute("error","Aadhar Number and password does not match");
	  return "userLogin"; 
	  }

	  }
	  
		/*
		 * public String balanceCheck(String uName, Model model) { // TODO
		 * Auto-generated method stub
		 * if(urepo.findById(uName).get().getSavingsAccountBalance()==0) {
		 * model.addAttribute("error","your current Account Balance is Rs. "+urepo.
		 * findById(uName).get().getCurrentAccountBalance()); return "aftersubmit"; }
		 * else {
		 * model.addAttribute("error","your savings Account Balance is Rs. "+urepo.
		 * findById(uName).get().getSavingsAccountBalance()); return "aftersubmit"; } }
		 */
	 
	
	
	/*
	 * public String accountChoice(User user, Model model, String uName) { // TODO
	 * Auto-generated method stub if(user.getUserType()==null) {
	 * model.addAttribute("error", "Select the account type"); return
	 * "withdrawType"; }
	 * 
	 * else if(user.getUserType().equals("Savings Account")) {
	 * System.out.println(uName);
	 * 
	 * model.addAttribute("sBalance",urepo.findById(uName).get().
	 * getSavingsAccountBalance()); model.addAttribute("uName", uName); return
	 * "withdrawPage"; } else if(user.getUserType().equals("Current Account")) {
	 * model.addAttribute("uName", uName);
	 * model.addAttribute("sBalance",urepo.findById(uName).get().
	 * getCurrentAccountBalance());
	 * 
	 * return "withdrawPage"; } return "aftersubmit"; } public String
	 * withdrawAmount(int sBalance, int samount, Model model, String uName) { //
	 * TODO Auto-generated method stub if (samount <= 0) {
	 * model.addAttribute("error", "invalid amount"); return "withdrawPage"; } if
	 * (sBalance < samount) { model.addAttribute("error",
	 * "Doesn't have enough Balance"); return "withdrawPage"; } else {
	 * 
	 * User user=urepo.findById(uName).get();
	 * user.setSavingsAccountBalance(user.getSavingsAccountBalance()-samount);
	 * user.setCurrentAccountBalance(user.getCurrentAccountBalance()-samount);
	 * urepo.save(user); model.addAttribute("error", "withdraw done successfully");
	 * return "aftersubmit"; } }
	 */

	
}
